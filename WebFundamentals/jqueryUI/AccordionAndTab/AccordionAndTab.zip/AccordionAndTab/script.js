$( function() {
    $( "#accordion" ).accordion();
  } );

$( function() {
$( "#tabs" ).tabs();
} );

$( function() {
  $( "#draggable" ).draggable();
} );