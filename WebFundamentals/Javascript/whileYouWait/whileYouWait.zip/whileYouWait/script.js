var daysUntilMyBirthday = 60;

while (daysUntilMyBirthday <= 60 && daysUntilMyBirthday >= 30){
    console.log("My birthay is not here soon enough " + daysUntilMyBirthday)
    daysUntilMyBirthday = daysUntilMyBirthday - 1
}
while (daysUntilMyBirthday < 30 && daysUntilMyBirthday > 5){
    console.log("Yeay my birthday is coming "+ daysUntilMyBirthday)
    daysUntilMyBirthday = daysUntilMyBirthday - 1
}
while (daysUntilMyBirthday <= 5 && daysUntilMyBirthday > 0){
    console.log("YES MY BIRTHAY IS COMING " + daysUntilMyBirthday)
    daysUntilMyBirthday = daysUntilMyBirthday - 1
}
console.log(daysUntilMyBirthday)
while(daysUntilMyBirthday == 0){
    console.log("Today is my birthday!!!!!!!")
    daysUntilMyBirthday = daysUntilMyBirthday - 1
}
