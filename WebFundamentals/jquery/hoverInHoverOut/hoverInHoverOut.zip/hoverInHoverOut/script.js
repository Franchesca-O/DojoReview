$(document).ready(function(){
    $('img').hover(
        function (){
            var alternate = $(this).attr('alt-src');
            $(this).attr('src', alternate);
        }, function (){
            var temp = $(this).attr('temp');
           $(this).attr('src', temp);
    })
});

