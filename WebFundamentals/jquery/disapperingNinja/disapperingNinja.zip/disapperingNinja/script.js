$(document).ready(function(){
    $('img').click(function(){
        $(this).hide();
    });
});