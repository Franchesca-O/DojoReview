
var number1 = 1000;
var number2 = -789;
var number3 = 0;
var number4 = 5.678;

var string1 = "I need to refresh my JavaScript";
var string2 = "Fron-end is awesome";
var string3 = "I'm excited for my new job";
var string4 = "I hope I become a good developer";

var boolean1 = true;
var boolean2 = false;

var whatever

console.log('The first number is', number1);
console.log('The second number is', number2);
console.log('The third number is', number3);
console.log('The fourth number is', number4);

console.log(string1)
console.log(string2)
console.log(string3)
console.log(string4)

console.log("I need to work hard", boolean1);
console.log("My dog is not cute", boolean2);

console.log(whatever);
console.log(typeof whatever);