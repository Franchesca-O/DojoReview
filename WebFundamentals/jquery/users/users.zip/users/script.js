$(document).ready(function(){
    
    $('form').submit( function(){
        var fname = $('#fname').val();
        var lname = $('#lname').val();
        var email = $('#email').val();
        var num = $('#num').val();
        
        $('table > tbody').append(
            "<tr><td>"+fname+"</td><td>"+lname+"</td><td>"+email+"</td><td>"+num+"</td></tr>");
        return false;
    }
)
});